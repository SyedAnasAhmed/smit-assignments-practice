// ==============================ASSIGNMENT 1======================================================
// 1 .Write a script to greet your website visitor using JS alert box.

// alert("welcome to our website" );

// 2 .Write a script to display following message on your web page:
// alert("Error ! Please enter a valid password");


// 3 . Write a script to display following message on your web page: (Hint : Use line break)
// alert("Welcome to Javascript Land...\n Happy Coding!");

// 4 Write a script to display following messages in sequence:
// alert("Welcome to JS Land..");
// alert("Happy Coding!");

//  5 Generate the following message through browser’s developer console:
// on console






// ==============================ASSIGNMENT 2======================================================


// 1. Declare a variable called username
// var username ;

// 2. Declare a variable called myName & assign to it a string that represents your Full Name.
// var myName = "Shaheeer Khan";


// 3. Write script to
//      a) Declare a JS variable, titled message.
//      b) Assign “Hello World” to variable message
//      c) Display the message in alert box.
// var smit="Hello World !";
// alert(smit);


// 4. Write a script to save student’s bio data in JS variables and show the data in alert boxes.
// var naam = "Jhone Doe";
// var age = "15 years old";
// var domain = "Certified Mobile Development";
// alert(naam);
// alert(age);
// alert(domain);

// 5. Write a script to display the following alert using one JS variable:
// var five= "\n PIZZA \n PIZZ \n PIZ \n PI \n P";
// alert(five);

// 6. Declare a variable called email and assign to it a string that represents your Email Address(e.g. example@example.com).
//       Show the blow mentioned message in an alert box.(Hint: use string concatenation)
// var mail="my Email address is ";
// var email= "shaheerk2145@gmail.com";
// var add= mail + email;
// alert(add);


// 7. Declare a variable called book & give it the value “A smarter way to learn JavaScript”.
//      Display the following message in an alert box:
// var book = "A smarter way to learn JavaScript";
// alert( "I am trying to learn from the Book " + book);


// 8. Write a script to display this in browser through JS
// done in html


// 9. Store following string in a variable and show in alert and browser through JS “▬▬▬▬▬▬▬▬▬ஜ ۩۞۩ ஜ▬▬▬▬▬▬▬▬▬”
// var variable = "▬▬▬▬▬▬▬▬▬ஜ ۩۞۩ ஜ▬▬▬▬▬▬▬▬▬";
// alert(variable);


// ==============================ASSIGNMENT 3    ====================================================
// 1. Declare a variable called age & assign to it your age. Show your age in an alert box.
// var age = 21;
// alert("My age is " + age + " years old");


// 2. Declare & initialize a variable to keep track of how many times a visitor has visited a web page.
//      Show his/her number of visits on your web page. For example: “You have visited this site N times”.
// var visitCount = 12;
// alert("You have visited this site " + visitCount + " times") ;

// 3. Declare a variable called birthYear & assign to it your birth year. Show the following message in your browser:
// var birthYear = 2002;
// console.log(birthYear);


// 4. A visitor visits an online clothing store www.xyzClothing.com . Write a script to store in variables the following information:
//      a. Visitor’s name b. Product title c. Quantity i.e. how many products a visitor wants to order
//      Show the following message in your browser: “John Doe ordered 5 T-shirt(s) on XYZ Clothing store”.
// var visitorsName = "John Doe";
// var productTitle = "tr1234" ;
// var quantity = "5 T-shirt(s)";
// var store =  "XYZ Clothing store";
// alert(visitorsName + " ordered " + quantity + " from " + store);











// ======================  ASSIGNMENT 4 ==============================

// 1. Declare 3 variables in one statement.
// var shaheer1, shaheer2 ,shaheer3;


// 2. Declare 5 legal & 5 illegal variable names.
// LEGAL VARIABLE:
// var $smit;
// var _javascript_ =222;
// var course;
// var html$ = 123;
// var react_js = "wwwwwwww";


// ILLEGAL VARIABLE:
// var 123;
// var @ubit;
// var smit678;
// var 12ssss;
// var wwdw21;

// 3. Display this in your browser
// a) A heading stating “Rules for naming JS variables”
// b) Variable names can only contain ______, ______, ______ and ______. For example $my_1stVariable
// c) Variables must begin with a ______, ______ or _____. For example $name, _name or name
// d) Variable names are case _________
// e) Variable names should not be JS _________

// var heading = "Rules for naming JS variables";
// var point1 = "Variable names can only contain numbers, $  and __. For example $my_1stVariable";
// var point2 = "Variables must begin with a letter,$ or __. For example $name, _name or name";
// var point3 =  "Variable names are case sensitive";
// var point4 = "Variable names should not be JS keywords";
// console.log(heading);
// console.log(point1 , "\n" ,point2, "\n" ,point3, "\n",point4);









// ================================== ASSIGNMENT   5  ===============================================
// 1. Write a program that take two numbers & add them in a new variable. Show the result in your browser.
// var numberOne = 2;
// var numberTwo = 3;
// var add= numberOne + numberTwo;
// console.log("sum of " ,numberOne, "and", numberTwo ,"is" ,add);
// 2. Repeat task1 for subtraction, multiplication, division & modulus.

// var numberOne = 2;
// var numberTwo = 3;
// var mul= numberOne * numberTwo;
// console.log( "Multiply of " ,numberOne, "and", numberTwo ,"is" ,mul);

// var numberOne = 2;
// var numberTwo = 3;
// var div= numberOne / numberTwo;
// console.log("Division of " ,numberOne, "and", numberTwo ,"is" ,div);

// var numberOne = 2;
// var numberTwo = 3;
// var sub= numberOne - numberTwo;
// console.log("Subtraction of " ,numberOne, "and", numberTwo ,"is" ,sub);


// 3. Do the following using JS Mathematic Expressions 
//      a. Declare a variable. 
// var duck;
//      b. Show the value of variable in your browser like “Value after variable declaration is: ??”.
// document.write("Value after variable declaration is: " + duck + "<br>");

//      c. Initialize the variable with some number.
// var duck = 5;
//      d. Show the value of variable in your browser like “Initial value: 5”.
// document.write("Initial Value :", duck + "<br>");
//      e. Increment the variable.
// duck++ ; 
//      f. Show the value of variable in your browser like “Value after increment is: 6”. 
// document.write("Value after increment  :", duck + "<br>");
//      g. Add 7 to the variable.
// var duck = duck +7;
//      h. Show the value of variable in your browser like “Value after addition is: 13”. 
// document.write("Value  after addition is :", duck + "<br>");
//      i. Decrement the variable.
// duck--;
//      j. Show the value of variable in your browser like “Value after decrement is: 12”. 
// document.write("Value after decrement :", duck + "<br>");
//      k. Show the remainder after dividing the variable’s value by 3.
// var duck = duck % 3;
//      l. Output : “The remainder is : 0”.
// document.write("The remainder is " , duck + "<br>");

// 4. Cost of one movie ticket is 600 PKR. Write a script to store ticket price in a variable & 
//     calculate the cost of buying 5 tickets to a movie. Example output:

// var cost = 600;
// cost * 5;
// document.write("Total cost to buy  5 tickets to a movie is " + cost);

// 5. Write a script to display multiplication table of any number in your browser. E.g
// var number = prompt("Enter the number ");
// var range = prompt("enter the range for the table");
// if ((number ) && (range)){
//     document.write("<h2>Multiplication Table for " + number + ":</h2>");
//     for (var i = 1; i <= range; i++) {
//         var result = number * i;
//         document.write(number + " x " + i + " = " + result + "<br>");
//     }
// } 
// else {
//     alert("Please enter valid numbers.");
// }
// 6. The Temperature Converter: It’s hot out! Let’s make a converter based on the steps here.
// a. Store a Celsius temperature into a variable.
// b. Convert it to Fahrenheit & output “NNoC is NNoF”.
// c. Now store a Fahrenheit temperature into a variable.
// d. Convert it to Celsius & output “NNoF is NNoC”.

// var fahrenhiet= prompt("Enter the temperature in fahrenhiet:");
// var degree = (fahrenhiet - 32) * 5/9;
// document.write("Temperature ",fahrenhiet,"in degree is " ,degree +"<br>");

// var degree= prompt("Enter the temperature in degree:");
// var fahrenhiet = (degree * 9/5 )+32;
// document.write("Temperature", degree + "in fahrenhiet is " ,degree);

// 7. Write a program to implement checkout process of a shopping cart system for an e-commerce website. Store the following in variables
// var price1 = prompt("Price of item 1 ");
// var price2 = prompt("price of item 2 is ");
// var item1 = prompt("item1 quantity");
// var item2 = prompt("quantity of item 2 is");
// var charge = prompt("Shipping charges:");
// document.write("Price of item 1 is " , price1 ,"<br>");
// document.write("Quantity of item 1 is" ,item1 ,"<br>");
// document.write("Price of item 2 is " , price2 ,"<br>");
// document.write("Quantity of item 2 is" ,item2 ,"<br>");
// document.write("Shipping charges " ,charges ,"<br>");
// var add = (price1 *  item1) + (price2 * item2) + charge;
// document.write("Total cost of your order is " , add);


// 8. Store total marks & marks obtained by a student in 2 variables. Compute the percentage & show the result in your browser

// var tmarks = 1100;
// var marksObt= prompt("Enter marks obtained ");
// var prc = (marksObt* 100)/tmarks;
// console.log("Total marks: ",tmarks);
// console.log("Marks obtained :",marksObt);
// console.log("Percentage is :",prc);


// 9. Assume we have 10 US dollars & 25 Saudi Riyals. Write a script to convert the total currency to Pakistani Rupees. Perform all calculations in a single expression. (Exchange rates : 1 US Dollar = 104.80 Pakistani Rupee and 1 Saudi Riyal = 28 Pakistani Rupee)
// var dlr =+prompt("enter money in dollars");
// var sda = +prompt("enter money in saudi Riyals");
// var dlrexchange = 286;
// var rylexchange = 76;
// var pkr = dlr * dlrexchange;
// var pkr2 = sda * rylexchange;
// var add = pkr + pkr2;
// console.log("Total Currency in PKR :", add);
// 10. Write a program to initialize a variable with some number and do arithmetic in following sequence:
//  a. Add 5 
//  b. Multiply by 10 
//  c. Divide the result by 2 Perform all calculations in a single expression

// var number = +prompt("Enter the number");
// var number = number + 5;
// console.log(number);
// var number = number *10;
// console.log(number);
// var number = number /2;
// console.log(number);


// 11. The Age Calculator: Forgot how old someone is? Calculate it! 
// a. Store the current year in a variable. 
// b. Store their birth year in a variable. 
// c. Calculate their 2 possible ages based on the stored values.

// var heading = "Age Calculator";
// console.log(heading);
// var cYear = 2023;
// var bYear = 2002;
// var sub = cYear -bYear;
// console.log("Current Year is",cYear);
// console.log("Birth year is",bYear);
// console.log("Your Age is : ", sub);


// 12. The Geometrizer: Calculate properties of a circle. 
//      a. Store a radius into a variable
//      b. Calculate the circumference based on the radius, and output “The circumference is NN”. (Hint : Circumference of a circle = 2 π r , π = 3.142) 
//      Calculate the area based on the radius, and output “The area is NN”. (Hint : Area of a circle = π r2, π = 3.142)

// var radius = +prompt("Enter radius of circle");
// var pie = 3.142;
// var circumference = 2* pie * radius;
// var area = pie * radius* radius;
// console.log("Radius of circle is :",radius);
// console.log("The circumference is :",circumference);
// console.log("The area is :",area);


// 13. The Lifetime Supply Calculator: Ever wonder how much a “lifetime supply” of your favorite snack is? Wonder no more.
//  a. Store your favorite snack into a variable
//   b. Store your current age into a variable. 
//   c. Store a maximum age into a variable. 
//   d. Store an estimated amount per day (as a number).
//    e. Calculate how many would you eat total for the rest of your life.
//    Output the result to the screen like so: “You will need NNNN to last you until the ripe old age of NN”.

// var snack= "lays";
// var age = +prompt("enter your age");
// var maxAge = 65;
// var day = prompt("enter the day(s)");
// var total = (maxAge - age ) * day;
// console.log( "Favourite snack " + snack);
// console.log( "Current Age "+ age);
// console.log( "Estimated Max Age "+maxAge);
// console.log( "Amount of snack per day "+ day);
// console.log( "You will need " + total + " days " + snack + " to last until  the rip old age of "+ maxAge);





// ==================== ASSIGNMENT 6-9 =============================================

// 1. Write a program to take a number in a variable, do the required arithmetic 
//      to display the following result in your browser:

// var number = 6;
// console.log("The value of number is " + number);
// ++number;
// console.log(number);
// console.log("The value of " + number + " is : " + number);
// console.log("Now the value of number is " + number);

// number++;
// console.log(number);
// console.log("The value of  number++ is : " + number);
// console.log("Now the value of number is " + number);

// --number;
// console.log(number);
// console.log("The value of  --number  is : " + number);
// console.log("Now the value of number is " + number);

// number--;
// console.log(number);
// console.log("The value of number-- is : " + number);
// console.log("Now the value of number is " + number);





// 2. What will be the output in variables a, b & result after execution of the following script: 
//      var a = 2, b = 1; 
//      var result = --a - --b + ++b + b--;
//      Explain the output at each stage: 
//      --a;
//      --a - --b;
//      --a - --b + ++b;
//      --a - --b + ++b + b--;

// var a = 2;
// var b = 1;
// console.log(" a is ", a);
// console.log(" b is ", b);
// console.log(" ==================================== ");
// --a;
// console.log(" a is ", a);

// console.log("=======================================");
// var number = --a - --b;
// console.log(" a is ", a);
// console.log(" b is ", b);
// console.log(number);

// console.log("=======================================");
// var number2 = --a - --b + ++b;
// console.log(" a is ", a);
// console.log(" b is ", b);
// console.log(number2);


// console.log("=======================================");
// var number2 = --a - --b + ++b + b--;
// console.log(" a is ", a);
// console.log(" b is ", b);
// console.log(number2);




// 3. Write a program that takes input a name from user & greet the user.
// var name = prompt("enter the name");
// console.log("hello" + name + " Welcome to our club");


// 5. Write a program to take input a number from user & display it’s multiplication table on your browser. 
//      If user does not enter a new number, multiplication table of 5 should be displayed by default


// var userInput = +prompt("Enter a number:");

// if (!isNaN(userInput)) {
//     document.write("<h2>Multiplication Table for " + userInput + ":</h2>");
//     for (var i = 1; i <= 10; i++) {
//         var result = userInput * i;
//         document.write(userInput + " x " + i + " = " + result + "<br>");
//     }
// } else {
//     document.write("<h2>Multiplication Table for 5 (Default):</h2>");
//     for (var i = 1; i <= 10; i++) {
//         var result = 5 * i;
//         document.write("5 x " + i + " = " + result + "<br>");
//     }
// }



// 6. Take
// a) Take three subjects name from user and store them in 3 different variables.
// b) Total marks for each subject is 100, store it in another variable.
// c) Take obtained marks for first subject from user and stored it in different variable.
// d) Take obtained marks for remaining 2 subjects from user and store them in variables.
// e) Now calculate total marks and percentage and show the result in browser like this.(Hint: user table)


// var subj1 = prompt("Enter the subject 1 ");
// var subj2 = prompt("Enter the subject 2 ");
// var subj3 = prompt("Enter the subject 3 ");
// totalMarks =100;
// var marksObt1 = +prompt("Enter the obtained marks for subject 1");
// var marksObt2 = +prompt("Enter the obtained marks for subject 2");
// var marksObt3 = +prompt("Enter the obtained marks for subject 3");
// var total1 = totalMarks * 3;
// var total2 = marksObt1 + marksObt2 + marksObt3;
// var total3 = perc1 + perc2 + perc3; 
// var perc1 = (marksObt1 * 100) / totalMarks;
// var perc2 = (marksObt2 * 100) / totalMarks;
// var perc3 = (marksObt3 * 100) / totalMarks;
// document.write("<h1>Subject  Total marks  Obtained Mark  Percentage </h1>");
// document.write(subj1 + "    " + totalMarks +  "      " +  marksObt1 + "         " +  perc1 + " % " + "<br>" );
// document.write(subj2 + "    " + totalMarks +  "      " +  marksObt2 + "         " +  perc2 + " % " + "<br>" );
// document.write(subj3 + "    " + totalMarks +  "      " +  marksObt3 + "         " +  perc3 + " % " + "<br>" );




// ==============================  ASSIGNMENT 10 11 ==============================================




// 1. Write a program to take “city” name as input from user.
//       If user enters “Karachi”, welcome the user like this: “Welcome to city of lights”

// var city = prompt("Enter the city name");
// if (city === "karachi"){
//     document.write("Welcome to city of lights:" , city);
// } else{
//     document.write("You put a wrong city:" ,city );
// }

// 2. Write a program to take “gender” as input from user. If the user is male, give the message: Good Morning Sir. 
//      If the user is female, give the message: Good Morning Ma’am.

// var gender = prompt("enter the gender");
// if (gender === "male"){
//     document.write("Good Morning Sir");
// } else if{
//     document.write("Good Morning Mam")
// } else {
// document.write("Invalid ! Please write only meale or female");
// }
// 3. Write a program to take input color of road traffic signal from the user & show the message according to this table:

// var traffic = prompt("Choose the color of traffic light");
// if (traffic === "Red"){
//     document.write( traffic , "               Must stop ");
// } else if (traffic === "Yellow"){
//     document.write( traffic +  "       Ready to move");
// } else if (traffic === "green"){
//     document.write( traffic  + "Move now");
// } else {
//     document.write("Invalid input. Please enter red, yellow, or green.");
// }

// 4. Write a program to take input remaining fuel in car (in litres) from user. If the current fuel is less than 0.25litres, show the message “Please refill the fuel in your car”
// var petrol =  +prompt("Enter the leftover fuel");
// if (petrol < 0.25 ){
//     document.write("Please refill the fuel in your car");
// }else {
//     document.write("You have enough fuel as of now");
// }



// 5. Run this script, & check whether alert message would be displayed or not. Record the outputs.

// a
// var a = 4;
// if (++a === 5) {
//     alert("given condition for variable a is true");
// }
// // OUTPUT
// given condition for variable a is true


// // ---------------------------------------------

// // b
// var b = 82;
// if (b++ === 83){
//     alert("given condition for variable b is true"); 
// }


// //  c. 
// var c = 12;
// if (c++ === 13)
// {
//     alert("condition 1 is true"); 
// } 
// if (c === 13){ 
//     alert("condition 2 is true"); 
// } 
// if (++c < 14){ 
//     alert("condition 3 is true"); 
// } 
// if(c === 14){ 
//     alert("condition 4 is true"); 
// }


// //  d. 
// var materialCost = 20000; 
// var laborCost = 2000; 
// var totalCost = materialCost + laborCost; 
// if (totalCost === laborCost + materialCost){ 
//     alert("The cost equals"); 
// }


// // e. 
// if (true){ 
//     alert("True"); 
// } 
// if (false){ 
//     alert("False"); 
// }
// // f. 
// if("car" < "cat"){ 
//     alert("car is smaller than cat"); 
// }

// 6. Write a program to take input the marks obtained in three subjects & total marks. Compute & show the resulting percentage on your page. Take percentage & compute grade as per following table:
// Show the total marks, marks obtained, percentage, grade & remarks like:

// var marksObt1 = +prompt("Enter the marks of subject one");
// var marksObt2 = +prompt("Enter the marks of subject two");
// var marksObt3 = +prompt("Enter the marks of subject three");
// var totalMarks = 300;
// var add = marksObt1 + marksObt2 +marksObt3;
// var perc = (add * 100) / totalMarks;
// var grade;
// var remarks;
// if (perc >= 80 ){
//     grade = "A+";
//     remarks = "Excellent";
// }
// else if (perc >= 70){
//     grade = "A";
//     remarks = "Good";

// } 
// else if( perc >= 60){
//     grade = "B";
//     remarks = "You need to improve";
// } 
// else{
//     grade = "Fail";
//     remarks = "Sorry";
// }

// document.write("<h2>Result Card</h2> <br/>");
// document.write("Total Marks :" + totalMarks  + "<br/>" );
// document.write("Marks Obtained: " + add + "<br/>");
// document.write("Percentage : " + perc + "<br/>");
// document.write("Grade : " + grade + "<br/>");
// document.write("Remarks : " + remarks + "<br/>");

// 7. Guess game:
// Store a secret number (ranging from 1 to 10) in a variable. Prompt user to guess the secret number.
//     a. If user guesses the same number, show “Bingo! Correct answer”.
// b. If the guessed number +1 is the secret number, show “Close enough to the correct answer”.
// var secNumber = Math.floor(Math.random() * 10) + 1;
// var guessNumber = +prompt("Select number from range 1 to 10");
// if (guessNumber === secNumber ){
//     alert("Bingo! Correct Answer");
// } else if (guessNumber === secNumber + 1){
//     alert("Close enough to the correct answer");
// } else {
//     alert("Sorry, that's not correct. The secret number was " + secNumber + ".");
// }


// 8. Write a program to check whether the given number is divisible by 3. Show the message to the user if the number is divisible by 3.
// var number = +prompt("Enter the number divisble by 3");

// if (number % 3 == 0){
//     document.write(  number + " Yes the number is divisible by 3 " );
// }
// else{
//     document.write("No give the right number");
// }


// 9. Write a program that checks whether the given input is an even number or an odd number.
// var number = +prompt("Enter the number");
// if (number % 2 == 0){
//     document.write("Even number" + number + "<br/>");
// } else{
//     document.write("Odd Number:" + number + "<br/>");
// }


// 10. Write a program that takes temperature as input and shows a message based on following criteria 
// a. T > 40 then “It is too hot outside.” 
// b. T > 30 then “The Weather today is Normal.” 
// c. T > 20 then “Today’s Weather is cool.” 
// d. T > 10 then “OMG! Today’s weather is so Cool.”
// var temperature = +prompt("Enter the temperature");
// if (temperature > 40 ){
//     document.write("It is too hot outside");
// } else if (temperature > 30){
//     document.write("The weather today is normal");
// } else if ( temperature > 20){
//     document.write("Today’s Weather is cool.");
// } else if (temperature > 10){
//     document.write("OMG! Today’s weather is so Cool.");
// } else {
//     document.write("Not the above given temperature .Anyways its too cold");
// }

// 11. Write a program to create a calculator for +,-,*, / & % using if statements. Take the following input:
//  a. First number 
//  b. Second number 
// c. Operation (+, -, *, /, %) Compute & show the calculated result to user.

// var firstNumber = +prompt("Enter the first number");
// var secondNumber = +prompt("Enter the second number");
// var operators = prompt("Operator is ")
// if (operators === "+" ){
//     var  add = firstNumber + secondNumber;
//     document.write("The answer is " +  add);
// } else if (operators === "-" ){
//     var sub = firstNumber - secondNumber;
//     document.write("The answer is " +  sub);
// }
// else if (operators === "*" ){
//     var mul = firstNumber * secondNumber;
//     document.write("The answer is " +  mul);
// }
// else if (operators === "/" ){
//     var div = firstNumber / secondNumber;
//     document.write("The answer is " +  div);
// }
// else if (operators === "%" ){
//     var mod = firstNumber % secondNumber;
//     document.write("The answer is " +  mod);
// }
// else {
//     document.write("Operator is not correct");
// }


// ================================ ASSIGNMENT 12 -13 ======================================


// 1. Write a program that takes a character (number or string)in a variable & checks whether the given input is a
//      number, uppercase letter or lower case letter. (Hint: ASCII
//      codes:- A=65, Z=90, a=97, z=122).
// var character = prompt("Enter the character (number or string)");
// var asciiCode = character.charCodeAt(0);
// if (!isNaN(character)){
//     alert("this is a number");
// }
// else if (asciiCode >= 65 && asciiCode <= 90){
//     alert("this is an uppercase letter");
// }
// else if (asciiCode >= 97 && asciiCode <= 122){
//     alert("this is a lowercase letter");
// }else{
//     alert("invalid input");
// }



// 2. Write a JavaScript program that accept two integers and display the larger.
//     Also show if the two integers are equal.
// var int1 =+prompt("Enter first integer");
// var int2 =+prompt("Enter second integer");
// if (int1 > int2){
//     document.write(int1 + " is larger than " + int2);
// }else if (int1 === int2){
//     document.write(int1 + " is equal to" + int2);
// }else{
//     document.write(int1 + " is smaller than " + int2);
// }


// 3. Write a program that takes input a number from user & state whether the number is positive, negative or zero.

// var number = +prompt("Enter the number");
// if (number > 0){
//     document.write("number is positive  " + number );

// }
// else if (number === 0){
//     document.write("number is equal to zero");
// }else {
//     document.write("number is negative");
// }


// 4. Write a program that takes a character (i.e. string of length 1)
//    and returns true if it is a vowel, false otherwise

// var character = prompt("Enter the character");
// character =character.toLowerCase();
// var isvowel = false;

// if (character === "a" || character === "e" || character === "i" || character === "o"  || character === "u"){
//     document.write(character + "->  It is a vowel");
// }else{
//     document.write( character + "->   it is a consonant")
// }

// 5. Write a program that
//    a. Store correct password in a JS variable.
//   b. Asks user to enter his/her password
//   c. Validate the two passwords:
// i. Check if user has entered password. If not, then give message “ Please enter your password”
// ii. Check if both passwords are same. If they are same, show message “Correct! The password you
//       entered matches the original password”. Show “Incorrect password” otherwise.

// var password1 = "shaheerk2145";
// var password2 = prompt("Enter your password2");
// if (password2 === null || password2 === ""){
//     document.write("Please Enter your password");
// } else if (password1 === password2){
//     document.write("Correct! The password you entered is the correct password");
// } else{
//     document.write("incorrect Password");
// }


// 6. This if/else statement does not work. Try to fix it:
// var greeting; 
// var hour = 13; 
// if (hour < 12) {
//     greeting = "Good day"; 
//     document.write(greeting);
// }else{ 
//     greeting = "Good evening";
//     document.write(greeting); 
// }


// 7. Write a program that takes time as input from user in 24 hours clock format like: 
// 1900 = 7pm. Implement the following case using if, else & else if statements

// var time = parseInt(prompt("Enter the time in 24-hour clock format (e.g., 1900):"));

// var hours = Math.floor(time / 100);
// var minutes = time % 100;
// let hours12h;
// let meridian;
// if (hours < 12) {
//     meridian = "am";
//     if (hours === 0) {
//         hours12h = 12;
//     } else {
//         hours12h = hours;
//     }
// } else {
//     meridian = "pm";
//     if (hours === 12) {
//         hours12h = hours;
//     } else {
//         hours12h = hours - 12;
//     }
// }
// alert(`The time in 12-hour clock format is: ${hours12h.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')} ${meridian}`);

