alert("hello world")


var num1 = 25;
var result = num1-- + num1++ + num1++ - --num1 - --num1 - num1-- + num1;
console.log(result);

var num2 = 38;
var result2 = ++num2 + ++num2 - --num2 - num2 + num2;
console.log(result2)


var num3 = 8;
var result3 = num3 + num3 + ++num3 + --num3 - --num3 + ++num3 + --num3 - num3;
console.log(result3)